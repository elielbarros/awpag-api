package com.algaworks.awpag;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AwpagApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(AwpagApiApplication.class, args);
	}

}
